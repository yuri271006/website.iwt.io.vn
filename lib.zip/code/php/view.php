<!--Tạo một hiển thị-->
<div class="app-item">
    <!--Phần thông tin một hiển thị-->
    <div class="app-item-info">
        <div class="i-p5">
            <img src="./media/img/base-i-avt.png" alt="Lỗi hiển thị." class="i-img">
            <b class="i-name" title="Tên của tác giả đăng nội dung này.">Admin Quí Cường</b>
        </div>
        <div class="i-post">
            <small>Chưa sẵn sàn hiển thị| Chờ nhé, Cường đang cố đây!</small>
        </div>
        <div class="i-caption">
            <p>Đây là video thử hệ thống.</p>
        </div>
    </div>
    <!--Phần hiển thị một phương tiện-->
    <div class="app-item-media">
    <iframe src="https://www.youtube.com/embed/HrocyJmU23U?si=62_rBLa7qGHuL0ob" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>
    <!--Các mở rộng tùy chọn-->
    <div class="app-item-open">
        <div class="choose"><i class="far fa-thumbs-up"></i> <span title="Thích" data="0"></span></div>
        <div class="choose"><i class="far fa-comment"></i> <span title="Bình luận" data="0"></span></div>
        <div class="choose"><i class="far fa-eye"></i> <span title="Xem thêm" data="0"></span></div>
    </div>
</div>
<!--Kết thúc một hiển thị-->
<!--Tạo một hiển thị-->
<div class="app-item">
    <!--Phần thông tin một hiển thị-->
    <div class="app-item-info">
        <div class="i-p5">
            <img src="./media/img/base-i-avt.png" alt="Lỗi hiển thị." class="i-img">
            <b class="i-name" title="Tên của tác giả đăng nội dung này.">Admin Quí Cường</b>
        </div>
        <div class="i-post">
            <small>...</small>
        </div>
        <div class="i-caption">
            <p>Thử các hệ thống dữ liệu</p>
        </div>
    </div>
    <!--Phần hiển thị một phương tiện-->
    <div class="app-item-media">
    <iframe src="https://www.youtube.com/embed/wZQaNlV1JFs?si=c0REKlYZRKM_Gwmm" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>    
    </div>
    <!--Các mở rộng tùy chọn-->
    <div class="app-item-open">
        <div class="choose"><i class="far fa-thumbs-up"></i> <span title="Thích" data="0"></span></div>
        <div class="choose"><i class="far fa-comment"></i> <span title="Bình luận" data="0"></span></div>
        <div class="choose"><i class="far fa-eye"></i> <span title="Xem thêm" data="0"></span></div>
    </div>
</div>
<!--Kết thúc một hiển thị-->
<!--Tạo một hiển thị-->
<div class="app-item">
    <!--Phần thông tin một hiển thị-->
    <div class="app-item-info">
        <div class="i-p5">
            <img src="./media/img/base-i-avt.png" alt="Lỗi hiển thị." class="i-img">
            <b class="i-name" title="Tên của tác giả đăng nội dung này.">Admin Quí Cường</b>
        </div>
        <div class="i-post">
            <small>...</small>
        </div>
        <div class="i-caption">
            <p>Thử hệ thống hình ảnh</p>
        </div>
    </div>
    <!--Phần hiển thị một phương tiện-->
    <div class="app-item-media">
       <img src="https://cdn3.ivivu.com/2014/12/chum-anh-tuyet-dep-ve-khung-canh-than-tien-cua-du-lich-nauy-iVIVU.com-1.jpg" alt="">
    </div>
    <!--Các mở rộng tùy chọn-->
    <div class="app-item-open">
        <div class="choose"><i class="far fa-thumbs-up"></i> <span title="Thích" data="0"></span></div>
        <div class="choose"><i class="far fa-comment"></i> <span title="Bình luận" data="0"></span></div>
        <div class="choose"><i class="far fa-eye"></i> <span title="Xem thêm" data="0"></span></div>
    </div>
</div>
<!--Kết thúc một hiển thị-->
<!--Tạo một hiển thị-->
<div class="app-item">
    <!--Phần thông tin một hiển thị-->
    <div class="app-item-info">
        <div class="i-p5">
            <img src="./media/img/base-i-avt.png" alt="Lỗi hiển thị." class="i-img">
            <b class="i-name" title="Tên của tác giả đăng nội dung này.">Admin Quí Cường</b>
        </div>
        <div class="i-post">
            <small>...</small>
        </div>
        <div class="i-caption">
            <p>Thử hệ thống hình ảnh</p>
        </div>
    </div>
    <!--Phần hiển thị một phương tiện-->
    <div class="app-item-media">
    <iframe src="https://www.nhaccuatui.com/lh/auto/q4UoLFFoW5mX" width="620" height="587" frameborder="0" allowfullscreen allow="autoplay"></iframe>
    </div>
    <!--Các mở rộng tùy chọn-->
    <div class="app-item-open">
        <div class="choose"><i class="far fa-thumbs-up"></i> <span title="Thích" data="0"></span></div>
        <div class="choose"><i class="far fa-comment"></i> <span title="Bình luận" data="0"></span></div>
        <div class="choose"><i class="far fa-eye"></i> <span title="Xem thêm" data="0"></span></div>
    </div>
</div>
<!--Kết thúc một hiển thị-->