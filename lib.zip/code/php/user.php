<div class="name">
    <img src="./media/img/iloading.jpg" alt="Đang tải...">
    <b><a href="./page/account.php">Cá nhân</a></b>
</div>
<div class="bookmark">
    <img src="./media/img/bookmark.png" alt="Đang tải...">
    <b><a href="./page/account.php">Đã lưu</a></b>
</div>
<div class="history">
    <img src="./media/img/history.png" alt="Đang tải...">
    <b><a href="./page/account.php">Đã xem</a></b>
</div>