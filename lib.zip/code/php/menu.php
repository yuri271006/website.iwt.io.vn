<div class="title">
    <b>Các tùy chọn của bạn</b>
    <div class="canvas"></div>
</div>
<div class="list_menu">
    <!--Các item-->
    <!--1--><div>
    <?php //?><img src="./media/img/report.png" alt="Lỗi dữ liệu">
              <a href="./page/report.php">Report</a>
              <canvas></canvas>
    <!--/--></div>
    <!--2--><div>
    <?php //?><img src="./media/img/question.png" alt="Lỗi dữ liệu">
              <a href="./page/fqa.html">FQA</a>
              <canvas></canvas>
    <!--/--></div>
    <!--3--><div>
    <?php //?><img src="./media/img/logo.png" alt="Lỗi dữ liệu">
              <a href="javascript:void(0)">Themes</a>
              <canvas></canvas>
    <!--/--></div>
</div>